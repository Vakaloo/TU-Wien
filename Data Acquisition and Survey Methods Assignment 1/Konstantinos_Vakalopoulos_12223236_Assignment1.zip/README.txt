Individual: Web Scraping & Basic Data Analysis
Author: Konstantinos Vakalopoulos 12223236

- Documents
  - Exercise 1.png
  - Exercise 2.png
  - Exercise 3.png
  - Konstantinos_Vakalopoulos_12223236_Assignment1.pdf
  - Konstantinos_Vakalopoulos_12223236_Assignment1.Rmd

The specific zip file contains 3 screenshots of the website data that was used, 
the PDF for the report, and finally the R Markdown file. The screenshots are included 
in the file because they are needed to execute the R Markdown correctly. 
To execute the R Markdown, simply hit the run button.

HAVE FUN!
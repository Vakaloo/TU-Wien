Konstantinos Vakalopoulos 12223236

File contents tree:

12223236_Case_Study_4.zip
|   12223236_Case_Study_4.pdf
|   README.txt
|   data_cia.rda
\---src
        app.R

The zip file contains the source code app.R, the documention in a
PDF format and the data that were used to build the app. All the implemented 
features are located in the source code (see documention for further information). 
The only thing that you have to do is to run the file app.R and to enjoy 
the application. 

HAVE FUN! 

Note: Do not forget to change the directory in the R file
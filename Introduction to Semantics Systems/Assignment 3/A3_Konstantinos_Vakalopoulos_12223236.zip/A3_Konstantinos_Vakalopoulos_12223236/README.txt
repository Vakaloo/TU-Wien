Konstantinos Vakalopoulos 12223236

File contents tree:

A3_Konstantinos_Vakalopoulos_12223236
|   A3_Konstantinos_Vakalopoulos_12223236.pdf
|   README.txt
|   
\---src
        kg_app.py

The file contains the source code kg_app.py and the documention in PDF format. All the implemented features are located
in the source code (see documention for further information). The only you have to do is to run the file kg_app.py and to enjoy the
application. 

HAVE FUN! 
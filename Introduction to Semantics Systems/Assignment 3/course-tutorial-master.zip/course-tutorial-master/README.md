# Course-Tutorial

- This is a simple example usage of both Jena, RDF4J, and rdflib
- The example implementation only cover some basic functionalities of these libraries, and therefore it's not a complete tutorial. 


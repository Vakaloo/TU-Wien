# How to run

- The code is developed using Maven framework, and therefore it is necessary to install Java and Maven before running the code
- Please take a look on the `Main.java` file to see example implementation.
- Use the following command to run the main file `mvn compile exec:java`
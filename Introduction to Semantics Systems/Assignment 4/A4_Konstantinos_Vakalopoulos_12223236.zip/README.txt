Konstantinos Vakalopoulos 12223236

File contents tree:

A4_Konstantinos_Vakalopoulos_12223236:
|-- Updated_film.owl
|-- A4_Konstantinos_Vakalopoulos_12223236.pdf

|-- Projects Open Refine
| |-- 1000-keywords-csv.openrefine.tar.gz
| |-- 1000-links-csv.openrefine.tar.gz
| |-- 1000-movies-metadata-csv.openrefine.tar.gz

|-- RML Mapping
| |-- 1000credits.txt
| |-- 1000movies.txt
| |-- 1000credits.rml.ttl
| |-- 1000movies.rml.ttl

|-- CSV ttl
| |-- 1000-keywords-csv.ttl
| |-- 1000-links-csv.ttl
| |-- 1000-movies-metadata-csv.ttl

|-- JSON ttl
| |-- 1000credits.ttl
| |-- 1000movies.ttl

|-- Knowledge Graphs
| |-- CSVKG.ttl
| |-- JSONKG.ttl
| |-- FinalKG.ttl

The file contains all the necessary files for the assignment 4 and the documention in PDF format.